
dir = "/dss/dsshome1/03/ge26xih2/up_test/Bench_100/*/*"
interval = [1 3]
frequency = 94e9;

calculate_rcs(dir ,interval, frequency)
